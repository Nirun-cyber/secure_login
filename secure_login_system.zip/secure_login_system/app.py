import io
import os
import secrets
import sqlite3
from functools import wraps
from pathlib import Path

import pyotp
import qrcode
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, VerificationError
from flask import (
    Flask, flash, redirect, render_template, request, session,
    url_for, send_file, abort
)
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_wtf.csrf import CSRFProtect

BASE_DIR = Path(__file__).resolve().parent
DATABASE = BASE_DIR / "users.db"
password_hasher = PasswordHasher()

app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.environ.get("SECRET_KEY", secrets.token_hex(32)),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "0") == "1",
    PERMANENT_SESSION_LIFETIME=1800,
    WTF_CSRF_TIME_LIMIT=3600,
)
CSRFProtect(app)
limiter = Limiter(get_remote_address, app=app, default_limits=["200 per day", "50 per hour"])


def get_db():
    connection = sqlite3.connect(DATABASE)
    connection.row_factory = sqlite3.Row
    return connection


def init_db():
    with get_db() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE COLLATE NOCASE,
                password_hash TEXT NOT NULL,
                totp_secret TEXT,
                totp_enabled INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)
        db.commit()


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in to access that page.", "warning")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


def valid_username(username):
    return 3 <= len(username) <= 30 and all(
        char.isalnum() or char in "._-" for char in username
    )


@app.after_request
def security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; style-src 'self' 'unsafe-inline'; "
        "img-src 'self' data:; form-action 'self'; frame-ancestors 'none'"
    )
    return response


@app.route("/")
def index():
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    return render_template("index.html")


@app.route("/register", methods=["GET", "POST"])
@limiter.limit("5 per minute", methods=["POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")

        if not valid_username(username):
            flash("Username must be 3–30 characters and use only letters, numbers, dot, underscore or hyphen.", "error")
        elif len(password) < 10:
            flash("Use a password with at least 10 characters.", "error")
        elif password != confirm:
            flash("Passwords do not match.", "error")
        else:
            password_hash = password_hasher.hash(password)
            try:
                with get_db() as db:
                    db.execute(
                        "INSERT INTO users (username, password_hash) VALUES (?, ?)",
                        (username, password_hash),
                    )
                    db.commit()
                flash("Account created. You can now log in.", "success")
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                flash("That username is already registered.", "error")
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
@limiter.limit("8 per minute", methods=["POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        with get_db() as db:
            user = db.execute(
                "SELECT * FROM users WHERE username = ?", (username,)
            ).fetchone()

        if user:
            try:
                password_hasher.verify(user["password_hash"], password)
                if password_hasher.check_needs_rehash(user["password_hash"]):
                    new_hash = password_hasher.hash(password)
                    with get_db() as db:
                        db.execute("UPDATE users SET password_hash = ? WHERE id = ?", (new_hash, user["id"]))
                        db.commit()
                if user["totp_enabled"]:
                    session.clear()
                    session["pending_2fa_user_id"] = user["id"]
                    return redirect(url_for("verify_2fa"))
                session.clear()
                session["user_id"] = user["id"]
                session["username"] = user["username"]
                session.permanent = True
                return redirect(url_for("dashboard"))
            except (VerifyMismatchError, VerificationError):
                pass

        flash("Invalid username or password.", "error")
    return render_template("login.html")


@app.route("/verify-2fa", methods=["GET", "POST"])
@limiter.limit("8 per minute", methods=["POST"])
def verify_2fa():
    pending_id = session.get("pending_2fa_user_id")
    if not pending_id:
        return redirect(url_for("login"))
    if request.method == "POST":
        code = request.form.get("code", "").strip().replace(" ", "")
        with get_db() as db:
            user = db.execute("SELECT * FROM users WHERE id = ?", (pending_id,)).fetchone()
        if user and user["totp_secret"] and pyotp.TOTP(user["totp_secret"]).verify(code, valid_window=1):
            session.clear()
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            session.permanent = True
            return redirect(url_for("dashboard"))
        flash("Invalid authentication code. Try again.", "error")
    return render_template("verify_2fa.html")


@app.route("/dashboard")
@login_required
def dashboard():
    with get_db() as db:
        user = db.execute("SELECT * FROM users WHERE id = ?", (session["user_id"],)).fetchone()
    return render_template("dashboard.html", user=user)


@app.route("/enable-2fa", methods=["POST"])
@login_required
def enable_2fa():
    with get_db() as db:
        user = db.execute("SELECT * FROM users WHERE id = ?", (session["user_id"],)).fetchone()
        if user["totp_enabled"]:
            flash("Two-factor authentication is already enabled.", "info")
            return redirect(url_for("dashboard"))
        secret = user["totp_secret"] or pyotp.random_base32()
        db.execute("UPDATE users SET totp_secret = ? WHERE id = ?", (secret, user["id"]))
        db.commit()
    session["setup_2fa"] = True
    flash("Scan the QR code with an authenticator app, then verify a code to enable 2FA.", "info")
    return redirect(url_for("setup_2fa"))


@app.route("/setup-2fa")
@login_required
def setup_2fa():
    if not session.get("setup_2fa"):
        return redirect(url_for("dashboard"))
    with get_db() as db:
        user = db.execute("SELECT * FROM users WHERE id = ?", (session["user_id"],)).fetchone()
    if not user["totp_secret"]:
        return redirect(url_for("dashboard"))
    uri = pyotp.TOTP(user["totp_secret"]).provisioning_uri(
        name=user["username"], issuer_name="Secure Login Mini Project"
    )
    return render_template("setup_2fa.html", secret=user["totp_secret"], uri=uri)


@app.route("/setup-2fa/qr.png")
@login_required
def setup_2fa_qr():
    if not session.get("setup_2fa"):
        abort(403)
    with get_db() as db:
        user = db.execute("SELECT * FROM users WHERE id = ?", (session["user_id"],)).fetchone()
    if not user or not user["totp_secret"]:
        abort(404)
    uri = pyotp.TOTP(user["totp_secret"]).provisioning_uri(
        name=user["username"], issuer_name="Secure Login Mini Project"
    )
    image = qrcode.make(uri)
    buffer = io.BytesIO()
    image.save(buffer, format="PNG")
    buffer.seek(0)
    return send_file(buffer, mimetype="image/png")


@app.route("/confirm-2fa", methods=["POST"])
@login_required
def confirm_2fa():
    code = request.form.get("code", "").strip().replace(" ", "")
    with get_db() as db:
        user = db.execute("SELECT * FROM users WHERE id = ?", (session["user_id"],)).fetchone()
        valid = user and user["totp_secret"] and pyotp.TOTP(user["totp_secret"]).verify(code, valid_window=1)
        if valid:
            db.execute("UPDATE users SET totp_enabled = 1 WHERE id = ?", (user["id"],))
            db.commit()
            session.pop("setup_2fa", None)
            flash("Two-factor authentication is now enabled.", "success")
            return redirect(url_for("dashboard"))
    flash("That code was not valid. Please try again.", "error")
    return redirect(url_for("setup_2fa"))


@app.route("/disable-2fa", methods=["POST"])
@login_required
def disable_2fa():
    password = request.form.get("password", "")
    with get_db() as db:
        user = db.execute("SELECT * FROM users WHERE id = ?", (session["user_id"],)).fetchone()
        try:
            password_hasher.verify(user["password_hash"], password)
        except (VerifyMismatchError, VerificationError):
            flash("Password incorrect. 2FA was not disabled.", "error")
            return redirect(url_for("dashboard"))
        db.execute("UPDATE users SET totp_secret = NULL, totp_enabled = 0 WHERE id = ?", (user["id"],))
        db.commit()
    flash("Two-factor authentication has been disabled.", "success")
    return redirect(url_for("dashboard"))


@app.route("/logout", methods=["POST"])
@login_required
def logout():
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("index"))


@app.errorhandler(429)
def too_many_requests(_error):
    return render_template("error.html", code=429, message="Too many attempts. Please wait a moment and try again."), 429


if __name__ == "__main__":
    init_db()
    app.run(debug=os.environ.get("FLASK_DEBUG", "0") == "1")
