# Secure Login System — Mini Project

A beginner-friendly secure login web application built with **Python Flask**, **SQLite**, and modern password/security libraries.

## Features

- User registration and login.
- Passwords hashed with **Argon2id** (via `argon2-cffi`); plain-text passwords are never stored.
- Server-side input validation and parameterized SQL queries to reduce SQL injection risk.
- Flask sessions with HTTP-only and SameSite cookie settings.
- CSRF protection on forms using Flask-WTF.
- Login and registration rate limits.
- Logout using a POST request.
- Optional Time-based One-Time Password (TOTP) two-factor authentication (2FA).
- Basic browser security headers.
- SQLite database created automatically on first run.

## Folder structure

```text
secure_login_system/
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
├── static/
│   └── style.css
└── templates/
    ├── base.html
    ├── index.html
    ├── register.html
    ├── login.html
    ├── verify_2fa.html
    ├── dashboard.html
    ├── setup_2fa.html
    └── error.html
```

## Requirements

- Python 3.9+
- pip
- VS Code (recommended)

## Installation

Open a terminal in this folder.

### Windows PowerShell

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

If PowerShell blocks activation, use Command Prompt:

```bat
.venv\Scripts\activate.bat
```

### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Run the application

```bash
python app.py
```

On Windows, you can use:

```powershell
py app.py
```

Open this address in your browser:

`http://127.0.0.1:5000`

The SQLite database (`users.db`) is generated automatically when the application starts.

## How to test

1. Open the home page.
2. Select **Create account** and register with a username and a password of at least 10 characters.
3. Log in using the account.
4. On the dashboard, choose **Set up 2FA** to enable optional two-factor authentication.
5. Scan the QR code with an authenticator app (such as Google Authenticator or Microsoft Authenticator).
6. Enter the 6-digit code to confirm. Log out and log in again to test the 2FA challenge.
7. Log out using the navigation button.

## Security implementation

| Requirement | Implementation |
|---|---|
| Password storage | Argon2 password hashing |
| SQL injection protection | SQLite parameterized queries |
| Input validation | Server-side username and password checks |
| Session management | Flask signed session, HTTP-only and SameSite cookies, 30-minute lifetime |
| CSRF protection | Flask-WTF CSRF tokens |
| Brute-force mitigation | Flask-Limiter on login and registration |
| Optional 2FA | TOTP authenticator codes |
| Browser hardening | CSP, X-Frame-Options, nosniff, Referrer-Policy |
| Logout | POST request and session clearing |

## Important production configuration

This is an educational project and should not be deployed as-is for real customer accounts.

Before deployment:

1. Set a long, random `SECRET_KEY` in the environment. Do not rely on the development fallback.
2. Set `COOKIE_SECURE=1` when serving over HTTPS.
3. Run behind a production WSGI server (for example, Waitress on Windows or Gunicorn on Linux), not Flask's development server.
4. Use HTTPS everywhere.
5. Configure Flask-Limiter with a persistent shared storage backend (such as Redis); its default in-memory storage is not suitable for multi-worker production.
6. Add password reset, email verification, account recovery, audit logging, monitoring, and backup procedures before real use.
7. Protect the SQLite database file and never commit `users.db`, secrets, or real user data to GitHub.
8. Review the CSP and other headers for any additional resources introduced by future changes.

To set environment variables in Windows PowerShell for the current terminal:

```powershell
$env:SECRET_KEY = "replace-with-a-long-random-secret"
$env:COOKIE_SECURE = "0"  # Use 1 only when HTTPS is configured
py app.py
```

## Limitations

- No email verification or password reset flow.
- No recovery codes for 2FA; losing the authenticator requires a manual database/admin recovery in this demo.
- Rate limiting uses in-memory storage unless configured otherwise.
- The application has not undergone a professional security audit.

## Learning outcomes

You will practise Flask routing, HTML forms, SQLite database operations, password hashing, session handling, CSRF protection, rate limiting, TOTP-based 2FA, and secure coding principles.

## Responsible use

Use this project as a learning prototype. Do not collect real users' passwords or deploy it for public account access without additional security engineering and independent review.
